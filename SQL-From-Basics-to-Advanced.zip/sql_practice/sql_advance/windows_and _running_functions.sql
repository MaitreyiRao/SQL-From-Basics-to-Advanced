-- row_number()
-- over()::
-- 1.Assign a row number to every employee based on Salary (Highest to Lowest).
select Employee_Name,salary,row_number() over (order by salary desc) as row_nums from employees;
-- 2.Assign a row number based on Employee_ID (lowest to highest).
select Employee_ID,Employee_Name,row_number() over(order by Employee_ID ) as orow_nums from employees;
-- 3.Assign a row number based on Employee_Name (A to Z).
select Employee_Name,row_number() over(order by Employee_Name asc) as row_nums from employees;
-- partition by ::
-- 4.Assign a row number within each Department based on Salary (Highest to Lowest).
select Employee_Name,Department_ID,salary,row_number() over(partition by Department_ID order by salary desc ) as row_nums from employees;
-- 5.Find the highest-paid employee in each department.
with row_qun as (select Employee_Name,Department_ID,salary,row_number() over (partition by Department_ID order by salary desc) as row_nums from employees ) 
select * from row_qun where row_nums=1; 
-- ___________________________________________________________________________________________________________________________________________________________
-- 1.rank()
-- 1.Assign a rank to all employees based on Salary (Highest to Lowest).
select Employee_Name,salary, rank() over (order by salary desc) as rank_num from employees;
-- 2.Assign a rank based on Employee_ID (Lowest to Highest)
select Employee_ID,Employee_Name,rank() over (order by Employee_ID)as rank_num from employees;
-- 3.Assign a rank within each Department based on Salary (Highest to Lowest).
select Employee_ID,Employee_Name,Department_ID,salary,rank() over(partition by Department_ID order by salary desc) as rank_num from employees;

-- ____________________________________________________________________________________________________________________________________________________________
-- 2.DENSE_RANK()
-- 1.Assign a dense rank to all employees based on Salary (Highest to Lowest).
select Employee_Name,salary,dense_rank() over (order by salary desc) as dense_rank_num from employees;
-- 2.Assign a dense rank within each department based on Salary (Highest to Lowest).
select Employee_Name,Department_ID,salary,dense_rank() over (partition  by Department_ID order by salary desc) as dense_rank_num from employees;
-- 3.Find the highest-paid employee(s) in each department using DENSE_RANK().
with dense_rank_1 as (select Employee_Name,Department_ID,salary,dense_rank() over (partition  by Department_ID order by salary desc) as dense_rank_num from employees)
select * from dense_rank_1 where dense_rank_num=1;
-- ___________________________________________________________________________________________________________________________________________________________
-- 3.LEAD()::
-- 1.Show each employee's salary and the next employee's salary.
select Employee_Name,salary,lead(salary) over(order by salary desc) as lead_ from employees;
-- 2.Show each employee's ID and the next Employee_ID.
select Employee_ID, lead(Employee_ID) over(order by Employee_ID asc ) as lead_ from employees;
-- 3.Show each employee's next salary within their department using LEAD().
select Employee_Name,Department_ID,salary,
					row_number() over(partition by Department_ID order by salary ) as row_num,
                    lead(salary) over(partition by Department_ID order by salary ) as lead_partition from employees;
-- 4.Show each employee's current salary, next salary, and the salary difference (NextSalary - Salary) using LEAD().
SELECT Employee_Name,Salary,
       LEAD(Salary) OVER(ORDER BY Salary) AS NextSalary,
       LEAD(Salary) OVER(ORDER BY Salary) - Salary AS SalaryDifference
FROM employees;
-- using cte
 WITH salary_cte AS (SELECT Employee_Name,Salary,LEAD(Salary) OVER(ORDER BY Salary) AS NextSalary FROM employees)
SELECT Employee_Name,Salary,NextSalary,NextSalary - Salary AS SalaryDifference FROM salary_cte;           
-- ___________________________________________________________________________________________________________________________
-- 4.lag()
-- 1.Show each employee's salary and the previous employee's salary.
SELECT Employee_Name,Salary,LAG(Salary) OVER(ORDER BY Salary DESC) AS PreviousSalary FROM employees;
-- 2. Show each employee's ID and the previous Employee_ID.
SELECT Employee_ID,LAG(Employee_ID) OVER(ORDER BY Employee_ID) AS PreviousEmployeeID FROM employees;
-- **3. Show each employee's previous salary within their department using `LAG()`.**
SELECT Employee_Name,Department_ID,Salary,
					ROW_NUMBER() OVER(PARTITION BY Department_ID ORDER BY Salary) AS RowNum,
					LAG(Salary) OVER(PARTITION BY Department_ID ORDER BY Salary) AS PreviousSalary FROM employees;
-- **4. Show each employee's current salary, previous salary, and the salary difference (`Salary - PreviousSalary`) using `LAG().
SELECT Employee_Name,Salary,LAG(Salary) OVER(ORDER BY Salary) AS PreviousSalary,   
			Salary - LAG(Salary) OVER(ORDER BY Salary) AS SalaryDifference FROM employees;
-- uisng ctes
WITH salary_cte AS 
			(SELECT Employee_Name,Salary, LAG(Salary) OVER(ORDER BY Salary) AS PreviousSalary FROM employees)
			SELECT Employee_Name,Salary,PreviousSalary,
			Salary - PreviousSalary AS SalaryDifference FROM salary_cte;
-- ___________________________________________________________________________________________________________________________________
-- summ() over() 
-- 1.Show each employee's salary and the running total of salaries ordered by Employee_ID.
-- 2.Show each employee's salary and the running total of salaries ordered by Salary (Lowest to Highest).
-- 3.Show each employee's running salary total within their department.
select Employee_ID,Employee_Name,Department_ID,salary,sum(salary) over (partition by Department_ID order by Employee_ID asc ) as sum_ from employees;
-- ___________________________________________________________________________________________________________________________________
-- avg() over()
SELECT Employee_Name,
       Salary,
       AVG(Salary) OVER(ORDER BY Employee_ID) AS RunningAverage
FROM employees;
-- ___________________________________________________________________________________________________________________________________
-- COUNT() OVER()
SELECT Employee_Name,
       COUNT(*) OVER(ORDER BY Employee_ID) AS RunningCount
FROM employees;
-- ___________________________________________________________________________________________________________________________________
-- MIN() OVER()
SELECT Employee_Name,
       Salary,
       MIN(Salary) OVER(ORDER BY Employee_ID) AS RunningMinimum
FROM employees;
-- ___________________________________________________________________________________________________________________________________
-- MAX() OVER()
SELECT Employee_Name,
       Salary,
       MAX(Salary) OVER(ORDER BY Employee_ID) AS RunningMinimum
FROM employees;