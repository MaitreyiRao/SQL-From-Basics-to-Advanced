-- outer join/full join
-- FULL OUTER JOIN = real SQL concept
-- BUT not available in MySQL
-- so ,LEFT JOIN + RIGHT JOIN + UNION
-- LEFT JOIN  → gives all left side data
-- RIGHT JOIN → gives all right side data
-- UNION removes duplicates + merges both results
-- 
select e.Employee_Name,
		d.Department_Name
from employees e
  join departments d
on e.Department_ID=d.Department_ID 
union
select e.Employee_Name,
		d.Department_Name
from employees e
right join departments d
on e.Department_ID=d.Department_ID ;

