describe employees;
describe departments;
describe employee_projects;
describe projects;
-- LEFT JOIN 
-- Q1:Display every employee along with their department name, even if the employee does not belong to any department.
select e.Employee_Name,d.Department_Name
from employees e
left join departments d
on e.Department_ID=d.Department_ID;
-- q2:Display all departments and the employees working in them. Show departments even if they have no employees.
select e.Employee_Name,d.Department_Name
from departments d 
left join employees e
on e.Department_ID=d.Department_ID;
-- q3:Display all employees and their project names. Show employees even if they are not assigned to any project.
select e.Employee_Name,p.Project_Name
from employees e
left join employee_projects ep
on e.Employee_ID=ep.Employee_ID
left join projects p
on ep.Project_ID=p.Project_ID;