describe employees;
describe departments;
-- left join
-- - All rows from the LEFT table (`FROM` table)
-- Matching rows from the RIGHT table (`JOIN` table)
-- If no match exists, NULL is shown for the right table columns
select e.Employee_Name,d.Department_Name
from employees e
left join departments d
on e.Department_ID=d.Department_ID;
-- where
select e.Employee_Name,
       d.Department_Name
from employees e
left join departments d
on e.Department_ID=d.Department_ID
where d.Department_Name='IT';
-- 3 tbales
SELECT e.Employee_Name,
       d.Department_Name,
       p.Project_Name
FROM employees e
LEFT JOIN departments d
ON e.Department_ID = d.Department_ID
LEFT JOIN employee_projects ep
ON e.Employee_ID = ep.Employee_ID
LEFT JOIN projects p
ON ep.Project_ID = p.Project_ID;