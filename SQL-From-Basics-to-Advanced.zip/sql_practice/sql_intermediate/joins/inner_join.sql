show databases;
use sql_practice;
show tables;
describe employees;
describe departments;
describe attendance;
describe employee_projects;

-- INNER JOIN
-- 1. Columns you want in output must be written in SELECT
-- 2. Table order is usually not important in INNER JOIN
-- because only matching records from both tables are returned
-- 3. Use aliases to make queries shorter and easier to read
-- 4. Use ON keyword to specify the matching column between the two tables
-- 2 tables
SELECT e.Employee_Name,
       d.Department_Name
FROM employees e
INNER JOIN departments d
ON e.Department_ID = d.Department_ID;
-- 3 tables yes in single quiery can have multiple inner joins(more than 10 inner join in single query )
-- fact table in froma nd dimension table in inner join line (industry standards)
select e.employee_Name,
		d.Department_Name,
        a.Status
from employees e
inner join departments d
on e.Department_ID=d.Department_ID
inner join attendance a
on e.Employee_ID=a.Employee_ID;

-- employee wise working hrs
SELECT e.Employee_Name,
       d.Department_Name,
       SUM(ep.Hours_Worked) AS Total_Hours
FROM employees e
INNER JOIN departments d
ON e.Department_ID = d.Department_ID
INNER JOIN employee_projects ep
ON e.Employee_ID = ep.Employee_ID
GROUP BY e.Employee_Name,
         d.Department_Name
HAVING SUM(ep.Hours_Worked) > 50
ORDER BY Total_Hours DESC;