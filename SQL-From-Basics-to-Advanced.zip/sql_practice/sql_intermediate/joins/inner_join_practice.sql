use sql_practice;
show tables;
describe employees;
describe departments;
describe projects;
describe employee_projects;
-- inner join practice 
-- 1.Write a query to display each employee's name along with their department name.
select e.Employee_Name,d.Department_Name
from employees e
inner join departments d
on e.Department_ID=d.Department_ID;
-- 2.Display Employee_Name, Salary, and Department_Name for all employees.
select e.Employee_Name,e.Salary,d.Department_Name
from employees e
inner join departments d
on e.Department_ID=d.Department_ID;
-- 3.1:Display all employees count who work in the IT department along with their salary. -- all employees or count of rows of it dept
select count(*),d.Department_Name 
from employees e
inner join departments d
on e.Department_ID=d.Department_ID
group by d.Department_Name 
having d.Department_Name='IT';
-- 3.2 same qun all employees 
select e.Employee_Name,d.Department_Name 
from employees e
inner join departments d
on e.Department_ID=d.Department_ID
where d.Department_Name='IT';
-- Interview Tip Pay attention to these words:
-- Display all employees → SELECT Employee_Name, ...
-- Count employees → COUNT(*)
-- Total employees → COUNT(*)
-- How many employees → COUNT(*)
-- List employees → Return rows, not a count.
-- 4.Display Employee_Name, Salary, and Department_Name for employees whose salary is greater than 60000.
select e.Employee_Name,e.Salary,d.Department_Name
 from employees e
 inner join departments d
 on e.Department_ID=d.Department_ID
 where salary>60000;
-- Phase 2 – Intermediate INNER JOIN (Real Job Level)
-- Now we'll start joining 3 tables, because that's what you'll do in projects and interviews.
-- 5.Display Employee_Name  and Project_Name for all employees.
select e.Employee_Name,p.Project_Name 
from employees e
inner join employee_projects ep
on e.Employee_ID=ep.Employee_ID
inner join  projects p
on ep.Project_ID=p.Project_ID;
-- 6.Display Employee_Name, Project_Name, and Hours_Worked for all employees.
select e.Employee_Name,p.Project_Name,ep.Hours_Worked
from employees  e
inner join employee_projects ep
on e.Employee_ID=ep.Employee_ID
inner join projects p
on ep.Project_ID=p.Project_ID;