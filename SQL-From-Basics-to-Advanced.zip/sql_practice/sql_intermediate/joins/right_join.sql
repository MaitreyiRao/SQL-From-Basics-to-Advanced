-- right join keep all rows right table and matched rows of left nad right table.
select e.Employee_Name,
		d.Department_Name
from employees e
right join departments d
on e.Department_ID=d.Department_ID
order by e.Employee_Name desc;
-- right + left
SELECT e.Employee_Name,
       d.Department_Name,
       p.Project_Name
FROM employees e

RIGHT JOIN departments d
ON e.Department_ID = d.Department_ID

LEFT JOIN employee_projects ep
ON e.Employee_ID = ep.Employee_ID

LEFT JOIN projects p
ON ep.Project_ID = p.Project_ID;


        