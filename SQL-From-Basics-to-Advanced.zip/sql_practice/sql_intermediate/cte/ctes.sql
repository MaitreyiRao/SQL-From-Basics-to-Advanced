use sql_practice;
show tables;
describe employees;
-- cte 
-- Using a CTE, create a temporary table containing only employees with salary greater than 50000, then display all columns from that CTE.
with emp_salary as (select * from employees where salary>50000) select * from emp_salary;
with dep_avg as (select Department_ID,avg(salary) from employees group by Department_ID order by Department_ID desc ) select * from dep_avg;
-- here we can use alias in in main query 
with dep_total_emp as (select Department_ID,count(*) from employees group by Department_ID  ) select * from dep_total_emp order by Department_ID desc;
-- JOIN + CTE
with join_cte as (select d.Department_Name,avg(e.salary) from employees e inner join departments d on e.Department_ID=d.Department_ID group by d.Department_Name) select * from join_cte;