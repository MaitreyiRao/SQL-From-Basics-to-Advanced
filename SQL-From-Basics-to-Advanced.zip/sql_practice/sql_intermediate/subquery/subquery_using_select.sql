-- subquery uisng select
-- SELECT → Create column/value
select (select count(*)  from employees )as total_emp;