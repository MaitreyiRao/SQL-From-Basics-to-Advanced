-- SUBQUERY USING FROM
-- WHERE Subquery→ Returns values
-- FROM Subquery→ Returns a temporary table
 SELECT *  FROM (SELECT * from employees)T;
 select Employee_ID from (select Employee_ID from attendance where status='Leave')a;
 select Department_ID from (select Department_ID from  projects where Project_Name='Project_1')p;
 
 