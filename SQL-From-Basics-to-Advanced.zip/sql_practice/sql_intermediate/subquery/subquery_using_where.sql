-- subquery using where
-- in select inner query only one colmun if not error
-- if u want one cloumn but based on filtering includes the another tbale column then subquery use 
select Employee_Name from employees where Department_ID in
(select Department_ID from departments where Department_Name='IT');
-- Get employees in HR department
select Employee_Name from employees where Department_ID in
(select Department_ID from departments where Department_Name='HR');
-- Get employees who Attendance staus = present AND Hours_Worked > 50
-- just outer select coumns will be in result grid inner/subquery jsut for connecting tables 
SELECT Employee_Name
FROM employees
WHERE Employee_ID IN (
    SELECT Employee_ID
    FROM attendance
    WHERE status = 'Present'
)
AND Employee_ID IN (
    SELECT Employee_ID
    FROM employee_projects
    WHERE Hours_Worked > 50
);