use sql_practice;
-- Find the names and salaries of employees who earn more than the average salary of all employees.
select Employee_Name,salary from employees where salary >(select avg(salary) from employees );
-- Find the names of employees who work in departments where at least one employee earns more than 80,000.(even on emp >8000 full dept comes in result )
select Employee_Name,Department_ID,salary from employees  where Department_ID in (select Department_ID from employees where salary>80000) ; 
-- Find the department(s) with the highest average salary.
select * from (select Department_ID,avg(salary) as avg_salary from employees group by Department_ID ) as dept_avg_salary;
-- Find the names of employees whose salary is equal to the highest salary in the company.
select Employee_Name,salary from employees where salary =(select max(salary) from employees );
-- Find the names of employees who work in the same department as employee 'John'.
select Employee_Name from employees where Department_Id =(select Department_ID from employees where Employee_Name='John');
-- Find the names of employees who work in departments where the average salary is greater than 70,000.
select Employee_Name from employees where Department_ID in (select Department_ID from employees  group by Department_ID having avg(salary)>70000);
-- Find the department(s) that have the highest average salary.
select * from (select avg(salary) as avg_salary,Department_ID from employees group by Department_ID) as Avg_salary_dept;
-- Find the names of employees who work in departments that have more than 5 employees.
select Employee_Name,Department_ID from employees where Department_ID in (select Department_ID from employees group by Department_ID having count(*)>5 );
-- Find the names of employees whose salary is greater than the minimum salary in the company.
select Employee_Name,salary from employees where salary >(select min(salary ) from employees);
-- Find the names of employees who work in departments that have exactly 3 employees.
select Employee_Name from employees where Department_ID in(select Department_ID from employees group by Department_ID having count(*)=3);
-- Write a CTE to find the average salary of each department, then display all rows from the CTE.
with avg_salary_dept as (select avg(salary) from employees  group by Department_ID  ) select  * from avg_salary_dept;
-- Write a CTE that stores employees earning more than 70,000, then display only their Employee_Name and Salary.
with salary_emp as (select salary,Employee_Name from employees where salary>70000) select Employee_Name,salary from salary_emp;
-- Write a CTE that stores the number of employees in each department, then display only departments having more than 3 employees.
with total_emp as (select Department_ID,count(*) as total_employees from employees group by Department_ID having count(*)>3) select * from total_emp order by total_employees desc;
-- Write a CTE that stores the average salary of each department, then display only the department(s) with the highest average salary.
with e as (select avg(salary) as avg_salary,Department_ID from employees group by Department_ID ) select avg_salary,Department_ID from e where avg_salary =(select  max(avg_salary) from e);
-- Display the names and salaries of employees whose salary is between 50,000 and 80,000 (inclusive).
select Employee_Name,salary from employees where salary between 50000 and 80000;
-- Display each Department_ID along with the average salary of that department,
--  but show only departments whose average salary is greater than 60,000. 
-- Order the results by average salary in descending order.
with avg_dep_salary as (select Department_ID,avg(salary) as avg_salary from employees group by Department_ID) select * from avg_dep_salary where avg_salary>60000 order by avg_salary desc;
-- Display the total number of employees in each department, but only for departments having at least 2 employees.
-- Rename the count column as total_employees.
select count(*) as total_employees,Department_ID from employees group by Department_ID having count(*)>2;
-- Display the highest salary in each department, but only for departments where the highest salary is greater than 90,000. 
-- Rename the column as highest_salary.
select * from  (select max(salary) as highest_salary , Department_ID from employees group by Department_ID  )dep where highest_salary>90000 ;
-- Find the employee(s) who earn the second highest salary.
select Employee_Name,salary from employees where salary =(select max(salary) from employees group by salary limit 1 offset 1);
-- Find the department(s) whose average salary is less than the overall average salary of the company.
WITH dept_avg AS (
    SELECT Department_ID,
           AVG(Salary) AS avg_salary
    FROM employees
    GROUP BY Department_ID
)
SELECT Department_ID, avg_salary
FROM dept_avg
WHERE avg_salary < (
    SELECT AVG(Salary)
    FROM employees
);