-- subquery (where)
-- INNER QUERY → produces result
--        ↓
-- OUTER QUERY → uses that result
--        ↓
-- FINAL OUTPUT
-- 1.Find employees whose salary is greater than the average salary of all employees.
select Employee_Name,salary from employees  where salary>
(select avg(salary) from employees );
-- 2.Find employees whose salary is greater than the maximum salary in the IT department
-- here i cna use 
select Employee_Name from employees where salary >
(select max(e.salary) from employees e inner join departments d on e.Department_ID=d.Department_ID  group by Department_Name having Department_Name='IT');
-- 3.Find employees who work for project_name 100(wihtout join also we can qrite queries)
select Employee_Name from employees where Employee_ID in (select Employee_ID from employee_projects where Project_ID=100);
-- 4.Find employees who earn more than the maximum salary of the HR department
select Employee_Name,salary from employees where salary>(select max(salary) from employees where Department_Id =
(select Department_Id from departments where Department_Name='HR'));
-- (FROM Subquery – Basic)
-- 1.Find average salary of each department and show only those departments where average salary > 60000
select avg(salary) ,Department_ID from employees group by Department_ID having avg(salary)>60000;
SELECT * FROM (SELECT Department_ID, AVG(Salary) AS avg_salary FROM employees GROUP BY Department_ID) AS dept_avg WHERE avg_salary > 60000;
-- 2.Find the maximum salary of each department, and show only those departments where max salary is greater than 80000.
select * from (select max(salary) as max_salary from employees group by Department_ID) as dep_max where max_salary>80000;
-- cte
with max_salary_dept as (select max(salary) as max_salary from employees group by Department_ID) select * from max_salary_dept where max_salary>80000;