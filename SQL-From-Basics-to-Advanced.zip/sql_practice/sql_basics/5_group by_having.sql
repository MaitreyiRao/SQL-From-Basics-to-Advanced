-- group by
-- group by (normal aggregate function gives single value but per each category we want separate single value )
-- aggregate + group by works together(if u use just grp by single cloumn it gives distinct clom values(cant use mutilple col in grp by ) )
select Department_ID from employees group by  Department_ID;
select distinct Department_ID as yes_distinct,Department_ID from employees group by Department_ID;
-- avg(salary) give single value but if we want department/category wise avg salary it collaps the rows into single vlaue/cell/row per department/category
-- count by department
-- Question answered:
-- How many employees are in each department?
select Department_ID, count(*) from employees group by Department_ID;
-- better readabale format use order by sorting
select Department_ID, count(*) from employees group by Department_ID order by Department_ID;
-- sum()
SELECT Department_ID,SUM(salary) AS Total_salary FROM employees GROUP BY Department_ID;
-- multiple aggregate fucntions
SELECT Department_ID,
       COUNT(*) AS Employees,
       AVG(salary)AS Avg_Salary,
       MAX(salary) AS Highest_Salary,
       MIN(salary) AS Lowest_Salary
FROM employees
GROUP BY Department_ID;

-- having (HAVING::After grouping, how do I filter the groups?)then having helps 
-- 1.execution flow of sql keywords check
-- from->where->group by->having->select->order by->limit
-- check this query
-- select Department_ID,avg(salary) from employees where salary>50000 group by Department_ID having avg(salary)>75000 order by Department_ID;
-- 2.WHERE  → filters rows
-- HAVING → filters groups
-- 3.can we yse having without group by? yes, Can HAVING be used without GROUP BY?
-- eg: SELECT COUNT(*) FROM employees HAVING COUNT(*) > 100;
-- MySQL allows this because the whole result is treated as one group.
-- practice
--  1: Departments with more than 100 employees?
select Department_ID from employees  group by Department_ID having count(*)>100 order by Department_ID ;
-- 2: Departments with average salary above 80000? (agregate + group by work together )
-- here we can us alis name in having but we mostly avoid 
select Department_ID,avg(salary)  as avg_salary from employees  group by Department_ID having avg(salary)>75000 order by Department_ID ;
-- 3: Using WHERE + HAVING together
select Department_ID,avg(salary) from employees where salary>50000 group by Department_ID having avg(salary)>75000 order by Department_ID;