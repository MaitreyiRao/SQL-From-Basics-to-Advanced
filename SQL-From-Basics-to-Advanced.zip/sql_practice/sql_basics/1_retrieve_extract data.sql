-- CEATE DATABSES PYTHON TO MYSQL(DOCKER) CONNECTION for csv files
CREATE DATABASE sql_practice;
USE sql_practice; 
show databases;
show tables;
-- Retrieve(Extract the data )
-- get full table;
SELECT * FROM employees; 
-- get sepcific column
select Employee_Name from employees;
-- rename column names alias
select Employee_Name as name from employees;
-- get unique/distinct values of column
select distinct Employee_Name from employees;
-- count the number of rows to diff all and distinct rowss 
select count(distinct Employee_Name),count(Employee_Name) from employees;
-- get specific number of rows 
select * from employees limit 5; 
