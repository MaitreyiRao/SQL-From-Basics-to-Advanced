-- Aggregate Data Functions ans in single value mostly 
-- count() how mnay rows
select count(*) from employees;
-- count distinct column totoal value
select count(distinct Department_id) from employees;
select count(salary) from employees where salary is null;
-- sum() performs on numeric value cloumns
select sum(salary) from employees ;
-- avg() 
select avg(salary) from employees ;
-- max value of the whole column
select max(salary) from employees ;
-- min value of the whole column
select min(salary) from employees ;
-- Multiple Aggregates Together each give sinlge cell value form the strcture/table format rows and cols so at the end  'from table_name' once enough
select 	count(*) as total_row,
		min(salary) as min_salary,
		max(salary) as max_salary,
		avg(salary) as avg_salary,
        sum(salary) as total_salary
        from employees;
-- aggregate + where (manipulation of data +filtering data using where  )
select max(salary) from employees where Department_ID=3;
        
 

