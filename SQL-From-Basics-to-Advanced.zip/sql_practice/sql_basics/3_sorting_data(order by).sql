-- sort data (order by )
-- asc is default  lowest ->highest and desc highest ->lowest
select * from employees order by salary asc;
select * from employees order by salary desc;
-- top 5 means hihg->low (use limit for specific number of rows )
select * from employees order by salary desc limit 5;
-- lowest 10 
select * from employees order by salary  limit 5;
-- sort by name
select * from employees order by Employee_Name ;
select * from employees where Employee_Name like 'm%' order by Employee_Name   limit 10;
-- sort by multiple columns(here which coumn is given 1st is priority clumn than next based on that next cloumn values bcz sql reads from left to right  )
select * from employees order by  salary desc,Department_ID desc;
-- check amx slary and abover query multy order by sorting priority changes 
select max(salary)  from employees;