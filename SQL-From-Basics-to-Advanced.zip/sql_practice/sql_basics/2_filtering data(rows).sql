-- filter data (rows)
-- 1st look at the table for filtering the rows
select * from employees;
-- using where keyword
select * from employees where salary >115000;
-- filter using multiple columns/condtions using and
select * from employees where salary >115000 and Department_ID = 3 ;
-- using or
select * from employees where salary >115000 or Department_ID = 3 or Department_ID = 5 ;
-- using in  range 
select * from employees where salary >115000 and Department_ID in (3,5);
-- using between
select * from employees where salary between 115000 and 117500 and Department_ID between 3 and 9;
-- using not 
-- (NOT IN
-- NOT BETWEEN
-- NOT LIKE
-- IS NOT NULL)

select * from employees where salary not in ( 115000 ,117500 );
select * from employees where  not salary  >110000;
-- using like for similar start/end/btwn valuues
select Employee_Name from employees
					where Employee_Name like 'A%'and 
                     Employee_Name like '%A'and 
                     Employee_Name like '%A%';
-- uisng is null / is not null (for 'null keyword' 'is keywords' always comes in sql )
select * from employees where salary is null;
select * from employees where salary is not null;



